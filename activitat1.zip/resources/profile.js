let button = document.querySelector('#view-profile');
let profile = document.querySelector('#profile');

document.querySelector('#view-profile').addEventListener("click", function(){
    document.querySelector('#profile').style.display="flex";
});

