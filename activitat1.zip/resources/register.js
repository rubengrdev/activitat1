  let register = getCookie("SuccessfullyRegistered");
  if(register == true){
    alert("Successfully Registered!");
   }