<?php
define('APP',__DIR__);
//datos acceso db
$dbname='school';
$dbhost = 'localhost';
$dbuser='prova';
$dbpasswd='debian';
$dsn='mysql:host='.$dbhost.';dbname='.$dbname.';charset=utf8mb4';
